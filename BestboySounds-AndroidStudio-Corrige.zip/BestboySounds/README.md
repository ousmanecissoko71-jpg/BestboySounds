# Bestboy Sounds - Projet Android Studio Complet

Ce projet est un projet Android Studio **100% complet et compilable**, prêt à être importé et exécuté immédiatement sur un émulateur ou appareil Android physique.

---

## 🛠️ Architecture & Technologies Utilisées

- **Langage** : Kotlin 2.0.21
- **UI Toolkit** : Jetpack Compose avec Material 3
- **Lecteur Audio & Service d'arrière-plan** : **AndroidX Media3 (ExoPlayer + MediaSessionService)**
- **Architecture** : MVVM (Model-View-ViewModel) avec Kotlin Coroutines et StateFlow
- **Publicité & Monétisation** : Google Mobile Ads SDK (AdMob) avec bannières et interstitiels
- **Compatibilité** :
  - `minSdk = 24` (Android 7.0 Nougat)
  - `targetSdk = 35` (Android 15)
  - Java 17

---

## 🚀 Comment Ouvrir & Compiler dans Android Studio

1. **Décompresser le fichier ZIP** :
   Extrayez le contenu de `BestboySounds-AndroidStudio.zip` dans un dossier de votre choix.

2. **Ouvrir Android Studio** :
   - Lancez **Android Studio** (Koala, Ladybug ou version récente).
   - Cliquez sur **File > Open...** (ou "Open" depuis l'écran d'accueil).
   - Sélectionnez le dossier racine `BestboySounds` et cliquez sur **OK**.

3. **Synchronisation Gradle** :
   - Android Studio va détecter les fichiers `settings.gradle.kts` et `build.gradle.kts` et lancer automatiquement le Gradle Sync.
   - Assurez-vous d'utiliser **JDK 17** (disponible dans *Settings > Build, Execution, Deployment > Build Tools > Gradle > Gradle JDK*).

4. **Lancer l'application** :
   - Sélectionnez votre émulateur (Pixel 8 / Android 14 ou 15) ou branchez votre smartphone avec le débogage USB activé.
   - Cliquez sur le bouton vert **Run 'app'** (Maj + F10).
   - L'application s'installe et s'ouvre avec l'activité principale (`MainActivity`).

---

## 📱 Points Clés Vérifiés

1. **Activité Launcher Déclarée** :
   Dans `app/src/main/AndroidManifest.xml`, `MainActivity` possède l'intent-filter avec `android.intent.action.MAIN` et `android.intent.category.LAUNCHER`. L'application apparaît immédiatement sur l'écran d'accueil Android.

2. **Service Media3 Fonctionnel** :
   `BestboyAudioService` implémente `MediaSessionService` avec le type de service foreground `mediaPlayback`, permettant la lecture audio même écran éteint avec commandes dans la barre de notifications.

3. **Configuration AdMob Sécurisée** :
   L'identifiant d'application AdMob de test officiel de Google (`ca-app-pub-3940256099942544~3347511713`) est inclus dans le Manifest, empêchant tout crash au démarrage. Remplacez-le par votre vrai ID lors de la mise en production.

4. **Fichiers Sons Inclus** :
   Les fichiers audio réels sont inclus dans `app/src/main/res/raw/` (`airhorn.wav`, `bruh.wav`, `bass_drop.wav`, `victory_fanfare.wav`, etc.).
