package com.bestboy.sounds.model

import androidx.annotation.RawRes

data class SoundItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: SoundCategory,
    val durationSeconds: Float,
    @RawRes val rawResId: Int,
    val isFavorite: Boolean = false,
    val colorHex: Long = 0xFF8B5CF6,
    val tags: List<String> = emptyList()
)
