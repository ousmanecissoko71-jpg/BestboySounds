package com.bestboy.sounds.data

import com.bestboy.sounds.R
import com.bestboy.sounds.model.SoundCategory
import com.bestboy.sounds.model.SoundItem

object SoundRepository {

    val sounds: List<SoundItem> = listOf(
        SoundItem(
            id = "airhorn",
            title = "Airhorn MLG",
            subtitle = "Le triple blast légendaire",
            category = SoundCategory.HORNS,
            durationSeconds = 1.8f,
            rawResId = R.raw.airhorn,
            colorHex = 0xFFEF4444,
            tags = listOf("mlg", "horn", "hype", "win")
        ),
        SoundItem(
            id = "bruh",
            title = "Bruh Sound #2",
            subtitle = "Réaction grave culte",
            category = SoundCategory.VIRAL,
            durationSeconds = 1.2f,
            rawResId = R.raw.bruh,
            colorHex = 0xFFF59E0B,
            tags = listOf("bruh", "meme", "viral", "reaction")
        ),
        SoundItem(
            id = "bass_drop",
            title = "Subwoofer 808",
            subtitle = "Onde de choc 35Hz",
            category = SoundCategory.BASS,
            durationSeconds = 2.5f,
            rawResId = R.raw.bass_drop,
            colorHex = 0xFF8B5CF6,
            tags = listOf("bass", "sub", "808", "drop", "trap")
        ),
        SoundItem(
            id = "victory_fanfare",
            title = "Victoire Fanfare",
            subtitle = "Niveau réussi style RPG",
            category = SoundCategory.GAMING,
            durationSeconds = 2.8f,
            rawResId = R.raw.victory_fanfare,
            colorHex = 0xFF10B981,
            tags = listOf("fanfare", "rpg", "retro", "win")
        ),
        SoundItem(
            id = "bonk",
            title = "Bonk Doge Bat",
            subtitle = "Coup de batte cartoon",
            category = SoundCategory.VIRAL,
            durationSeconds = 0.6f,
            rawResId = R.raw.bonk,
            colorHex = 0xFFEC4899,
            tags = listOf("bonk", "doge", "meme", "impact")
        ),
        SoundItem(
            id = "wow",
            title = "Anime Wow",
            subtitle = "Effet féerique scintillant",
            category = SoundCategory.REACTIONS,
            durationSeconds = 1.5f,
            rawResId = R.raw.wow,
            colorHex = 0xFF06B6D4,
            tags = listOf("anime", "wow", "reaction", "cute")
        ),
        SoundItem(
            id = "laser_pew",
            title = "Laser Pew Blaster",
            subtitle = "Tir plasma futuriste",
            category = SoundCategory.SCIFI,
            durationSeconds = 0.8f,
            rawResId = R.raw.laser_pew,
            colorHex = 0xFF3B82F6,
            tags = listOf("laser", "pew", "cyber", "scifi")
        ),
        SoundItem(
            id = "fart_reverb",
            title = "Prout Cathédrale",
            subtitle = "Réverbération acoustique hilarante",
            category = SoundCategory.VIRAL,
            durationSeconds = 2.1f,
            rawResId = R.raw.fart_reverb,
            colorHex = 0xFF84CC16,
            tags = listOf("fart", "funny", "meme", "reverb")
        )
    )
}
