package com.bestboy.sounds

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.bestboy.sounds.admob.AdMobManager
import com.bestboy.sounds.ui.screens.HomeScreen
import com.bestboy.sounds.ui.theme.BestboySoundsTheme
import com.bestboy.sounds.viewmodel.SoundPlayerViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: SoundPlayerViewModel by viewModels()

    // Demande de permission de notification (Android 13+ requise pour le service Media3)
    private val requestNotificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Géré silencieusement
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Précharger l'interstitiel AdMob
        AdMobManager.loadInterstitial(this)

        // Vérifier permission notification Android 13+
        checkNotificationPermission()

        setContent {
            BestboySoundsTheme(darkTheme = isSystemInDarkTheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    HomeScreen(
                        viewModel = viewModel,
                        onShowInterstitialAd = {
                            AdMobManager.showInterstitial(this)
                        }
                    )
                }
            }
        }
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Libération de ressources si nécessaire
    }
}
