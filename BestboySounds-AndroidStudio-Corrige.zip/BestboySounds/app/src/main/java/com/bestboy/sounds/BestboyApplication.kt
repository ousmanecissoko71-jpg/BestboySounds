package com.bestboy.sounds

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BestboyApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // 1. Initialiser le SDK AdMob en arrière-plan
        CoroutineScope(Dispatchers.IO).launch {
            MobileAds.initialize(this@BestboyApplication) {}
        }

        // 2. Créer le canal de notification pour le Media3 AudioService
        createMediaNotificationChannel()
    }

    private fun createMediaNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "bestboy_media_channel"
    }
}
