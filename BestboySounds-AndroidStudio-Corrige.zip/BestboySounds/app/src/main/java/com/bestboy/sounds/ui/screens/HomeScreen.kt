package com.bestboy.sounds.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bestboy.sounds.model.SoundCategory
import com.bestboy.sounds.ui.components.AdBanner
import com.bestboy.sounds.ui.components.PlayerBottomBar
import com.bestboy.sounds.ui.components.SoundPadCard
import com.bestboy.sounds.viewmodel.SoundPlayerViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: SoundPlayerViewModel,
    onShowInterstitialAd: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    // Filtrage des sons
    val filteredSounds = uiState.sounds.filter { sound ->
        val matchesCategory = (uiState.selectedCategory == SoundCategory.ALL) ||
                (sound.category == uiState.selectedCategory)
        val matchesSearch = uiState.searchQuery.isEmpty() ||
                sound.title.contains(uiState.searchQuery, ignoreCase = true) ||
                sound.tags.any { it.contains(uiState.searchQuery, ignoreCase = true) }
        matchesCategory && matchesSearch
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Bestboy Sounds",
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Column {
                PlayerBottomBar(
                    currentSound = uiState.currentSound,
                    isPlaying = uiState.isPlaying,
                    isLooping = uiState.isLooping,
                    pitch = uiState.pitch,
                    onTogglePlay = { viewModel.togglePlayPause() },
                    onStop = { viewModel.stop() },
                    onToggleLoop = { viewModel.toggleLoop() },
                    onPitchChange = { viewModel.setPitch(it) }
                )
                // Bannière publicitaire AdMob en pied d'écran
                AdBanner()
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Barre de recherche
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Rechercher un son ou un mot-clé...") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Search")
                },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Effacer")
                        }
                    }
                },
                singleLine = true
            )

            // Filtres par Catégorie
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(SoundCategory.values()) { category ->
                    FilterChip(
                        selected = uiState.selectedCategory == category,
                        onClick = { viewModel.selectCategory(category) },
                        label = { Text(category.displayName) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Grille de Pads Sonores
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredSounds, key = { it.id }) { sound ->
                    val isPlayingThis = uiState.isPlaying && uiState.currentSound?.id == sound.id
                    val isFav = uiState.favorites.contains(sound.id)

                    SoundPadCard(
                        sound = sound,
                        isPlaying = isPlayingThis,
                        isFavorite = isFav,
                        onPlayClick = {
                            viewModel.playSound(sound)
                            // Afficher l'interstitiel AdMob toutes les 10 lectures
                            if (uiState.playCount > 0 && uiState.playCount % 10 == 0) {
                                onShowInterstitialAd()
                            }
                        },
                        onFavoriteClick = {
                            viewModel.toggleFavorite(sound.id)
                        }
                    )
                }
            }
        }
    }
}
