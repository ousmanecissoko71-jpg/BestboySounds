package com.bestboy.sounds.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import com.bestboy.sounds.data.SoundRepository
import com.bestboy.sounds.model.SoundCategory
import com.bestboy.sounds.model.SoundItem
import com.bestboy.sounds.service.BestboyAudioService
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PlayerUiState(
    val sounds: List<SoundItem> = SoundRepository.sounds,
    val currentSound: SoundItem? = null,
    val isPlaying: Boolean = false,
    val isLooping: Boolean = false,
    val pitch: Float = 1.0f,
    val selectedCategory: SoundCategory = SoundCategory.ALL,
    val searchQuery: String = "",
    val favorites: Set<String> = emptySet(),
    val playCount: Int = 0
)

@OptIn(UnstableApi::class)
class SoundPlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("bestboy_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    init {
        loadFavorites()
        initMediaController()
    }

    private fun loadFavorites() {
        val saved = prefs.getStringSet("favorite_ids", emptySet()) ?: emptySet()
        _uiState.update { it.copy(favorites = saved) }
    }

    private fun initMediaController() {
        val context = getApplication<Application>()
        val sessionToken = SessionToken(
            context,
            ComponentName(context, BestboyAudioService::class.java)
        )

        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture?.addListener({
            try {
                mediaController = controllerFuture?.get()
                mediaController?.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        _uiState.update { it.copy(isPlaying = isPlaying) }
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_ENDED) {
                            _uiState.update { it.copy(isPlaying = false) }
                        }
                    }
                })
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, MoreExecutors.directExecutor())
    }

    fun playSound(sound: SoundItem) {
        val controller = mediaController ?: return
        val context = getApplication<Application>()

        val rawUri = Uri.parse("android.resource://${context.packageName}/${sound.rawResId}")

        val mediaMetadata = MediaMetadata.Builder()
            .setTitle(sound.title)
            .setArtist(sound.subtitle)
            .build()

        val mediaItem = MediaItem.Builder()
            .setMediaId(sound.id)
            .setUri(rawUri)
            .setMediaMetadata(mediaMetadata)
            .build()

        controller.setMediaItem(mediaItem)
        controller.repeatMode = if (_uiState.value.isLooping) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        controller.playbackParameters = PlaybackParameters(1.0f, _uiState.value.pitch)
        controller.prepare()
        controller.play()

        _uiState.update {
            it.copy(
                currentSound = sound,
                isPlaying = true,
                playCount = it.playCount + 1
            )
        }
    }

    fun togglePlayPause() {
        val controller = mediaController ?: return
        if (controller.isPlaying) {
            controller.pause()
            _uiState.update { it.copy(isPlaying = false) }
        } else {
            controller.play()
            _uiState.update { it.copy(isPlaying = true) }
        }
    }

    fun stop() {
        mediaController?.stop()
        _uiState.update { it.copy(isPlaying = false) }
    }

    fun toggleLoop() {
        val newLoop = !_uiState.value.isLooping
        _uiState.update { it.copy(isLooping = newLoop) }
        mediaController?.repeatMode = if (newLoop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    fun setPitch(newPitch: Float) {
        _uiState.update { it.copy(pitch = newPitch) }
        mediaController?.playbackParameters = PlaybackParameters(1.0f, newPitch)
    }

    fun selectCategory(category: SoundCategory) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun toggleFavorite(soundId: String) {
        val currentFavs = _uiState.value.favorites.toMutableSet()
        if (currentFavs.contains(soundId)) {
            currentFavs.remove(soundId)
        } else {
            currentFavs.add(soundId)
        }
        prefs.edit().putStringSet("favorite_ids", currentFavs).apply()
        _uiState.update { it.copy(favorites = currentFavs) }
    }

    override fun onCleared() {
        super.onCleared()
        controllerFuture?.let { MediaController.releaseFuture(it) }
    }
}
