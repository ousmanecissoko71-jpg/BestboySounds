package com.bestboy.sounds.model

enum class SoundCategory(val displayName: String) {
    ALL("Tous les sons"),
    VIRAL("Viral & Memes"),
    GAMING("Gaming & Rétro"),
    BASS("Bass & Drops"),
    HORNS("Klaxons & Sirènes"),
    REACTIONS("Réactions"),
    SCIFI("Sci-Fi & FX")
}
